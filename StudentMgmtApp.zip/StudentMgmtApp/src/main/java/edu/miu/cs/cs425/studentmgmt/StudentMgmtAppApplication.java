package edu.miu.cs.cs425.studentmgmt;

import edu.miu.cs.cs425.studentmgmt.model.Classroom;
import edu.miu.cs.cs425.studentmgmt.model.Student;
import edu.miu.cs.cs425.studentmgmt.model.Transcript;
import edu.miu.cs.cs425.studentmgmt.repository.ClassroomRepository;
import edu.miu.cs.cs425.studentmgmt.repository.TranscriptRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.miu.cs.cs425.studentmgmt.repository.StudentRepository;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@SpringBootApplication
public class StudentMgmtAppApplication implements CommandLineRunner {
	
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private TranscriptRepository transcriptRepository;
	@Autowired
	private ClassroomRepository classroomRepository;

	@Override
	public void run(String... args) throws Exception {


		// Transcript
		Transcript t1= new Transcript(1L, "BS Computer Science");


		// Classroom
		Classroom  c1= new Classroom(1L, "McLaughlin building", "M105");
		Classroom  c2= new Classroom(2L, "Verill Hall", "C30");
		List<Classroom> Classrooms = Arrays.asList(c1,c2);


		// Students
		Student s1 = new Student(1L,"000-61-0001","Anna","Lynn","Smith",3.45, LocalDate.of(2019, 5, 24),t1,Classrooms);
		Student s2 = new Student(2L,"000-61-1939","Ayoub","","LACHHAB",3.85, LocalDate.of(1995, 6, 25),t1,Classrooms);


		List<Student> Students = Arrays.asList(s1,s2);
		List<Student> savedStudents = saveStudent(Students);
		System.out.println("The Student : "+Students);

		Transcript savedtranscript1 = saveTranscript(t1);
		System.out.println("The Transcript : "+savedtranscript1);

		List<Classroom> savedClassrooms = saveClassroom(Classrooms);
		System.out.println("The Classroom : "+savedClassrooms);


	}

	public static void main(String[] args) {
		SpringApplication.run(StudentMgmtAppApplication.class, args);
	}

	private List<Student> saveStudent(List<Student> Students) {
		return (List<Student>) studentRepository.saveAll(Students);
	}

	private List<Classroom> saveClassroom(List<Classroom> classrooms) {
		return (List<Classroom>) classroomRepository.saveAll(classrooms);
	}

	private Transcript saveTranscript(Transcript transcript) {
		return transcriptRepository.save(transcript);
	}

}

package edu.miu.cs.cs425.studentmgmt.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table (name = "Classroom ")
public class Classroom {
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Id
    private Long classroomId;

    @Column(name="buildingName ", unique=true, nullable=false)
    private String buildingName ;
    @Column(name="roomNumber ", unique=true, nullable=false)
    private String roomNumber ;

    @ManyToMany(mappedBy = "Classrooms")
    private List<Student> students = new ArrayList<>();

    public Classroom(Long classroomId, String buildingName , String roomNumber) {
        this.classroomId = classroomId;
        this.buildingName = buildingName;
        this.roomNumber=roomNumber;
    }

    @Override
    public String toString() {
        return "Classroom{" +
                "classroomId=" + classroomId +
                ", buildingName='" + buildingName + '\'' +
                ", roomNumber=" + roomNumber +
                '}';
    }
}

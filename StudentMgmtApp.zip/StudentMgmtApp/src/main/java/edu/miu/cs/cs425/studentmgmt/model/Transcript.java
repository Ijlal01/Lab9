package edu.miu.cs.cs425.studentmgmt.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name="Transcript")
public class Transcript {

    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    private Long transcriptId;

    @Column(name="degreeTitle ", unique=true, nullable=false)
    private String degreeTitle ;

    @OneToOne(mappedBy = "transcript",
            cascade = CascadeType.ALL)
    private Student student;

    public Transcript(Long transcriptId, String degreeTitle) {
        this.transcriptId = transcriptId;
        this.degreeTitle = degreeTitle;
    }

    @Override
    public String toString() {
        return "Transcript{" +
                "transcriptId=" + transcriptId +
                ", degreeTitle='" + degreeTitle +
                '}';
    }
}

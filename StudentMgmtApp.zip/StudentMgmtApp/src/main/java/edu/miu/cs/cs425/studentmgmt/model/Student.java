package edu.miu.cs.cs425.studentmgmt.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.NoArgsConstructor;


@Getter
@Setter
@NoArgsConstructor
@Entity
@Table (name = "Student")
public class Student {

    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Id
    private Long StudentId;

    @NotBlank(message = "student Number  is required")
    @Column (name="studentNumber ", unique=true, nullable=false)
    private String studentNumber ;

    @Column (name="firstName ", unique=true, nullable=false)
    @NotBlank(message = "firstName is required")
    private String firstName ;

    @Column (name="middleName ", unique=true, nullable=false)
    private String middleName ;

    @Column (name="lastName ", unique=true, nullable=false)
    @NotBlank(message = "lastName is required")
    private String lastName ;

    @Column (name="cgpa  ", unique=true, nullable=false)
    private Double cgpa;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOfEnrollment ;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "transcriptId",
            nullable = false)
    private Transcript transcript;

    @ManyToMany(cascade = {CascadeType.ALL })
    @JoinTable()
    List<Classroom> Classrooms = new ArrayList<>();

    public Student(Long studentId, String studentNumber, String firstName, String middleName, String lastName, Double cgpa, LocalDate dateOfEnrollment, Transcript transcript, List<Classroom> classrooms) {
        StudentId = studentId;
        this.studentNumber = studentNumber;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.cgpa = cgpa;
        this.dateOfEnrollment = dateOfEnrollment;
        this.transcript = transcript;
        this.Classrooms = classrooms;
    }

    public Student(Long studentId, String studentNumber, String firstName, String middleName, String lastName, Double cgpa, LocalDate dateOfEnrollment) {
        StudentId = studentId;
        this.studentNumber = studentNumber;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.cgpa = cgpa;
        this.dateOfEnrollment = dateOfEnrollment;
    }

    @Override
    public String toString() {
        return "Student{" +
                "StudentId=" + StudentId +
                ", studentNumber='" + studentNumber + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", cgpa=" + cgpa +
                ", dateOfEnrollment=" + dateOfEnrollment +
                ", transcript=" + transcript +
                ", Classroom=" + Classrooms +
                '}';
    }
}
